public class Queue {
    private int count = 0;
    private int queueLineSize = 0;
    private Job head, tail;
    public Queue()
    {
        head = null;
        tail = null;
    }

    /** holds the data of objects inside the Queue
     *
     */
    private class Job
    {
        public Simulation.SimulatedJob data;
        public Job next;


        public Job(Simulation.SimulatedJob job)
        {
            data = job;
            next = null;
        }
    }

    /** adds @param obj to the queue and assigns the item to the head if the queue is empty
     */
    public void enqueue(Simulation.SimulatedJob job)
    {
        Job rec = new Job(job);
        if (isEmpty()) {
            head = rec;
            tail = rec;
            queueLineSize++;
        } else {
            tail.next = rec;
            tail = rec;
            queueLineSize++;
        }

    }

    /**
     * removes the first item in the queue
     *
     * @return
     */
    public Simulation.SimulatedJob dequeue()
    {
        if(!isEmpty())
        {
            Job temp = head;
            head = head.next;
            if(head == null)
            {
                tail = null;
            }
            temp.next = null;
            queueLineSize--;
            return temp.data;
        }
        else
        {
            System.out.println("Queue is Empty");
            return null;
        }
    }

    public int queueSize()
    {

        return queueLineSize;
    }

    /** checks if the queue is empty or not
     *
     * @return
     */
    public boolean isEmpty()
    {
        return head == null && tail == null;
    }




//    public static void unitTest()
//    {
//        Queue queueA = new Queue();
//        Simulation.SimulatedJob job = new Simulation.SimulatedJob();
//        queueA.enqueue("dog");
//        queueA.enqueue("cat");
//        System.out.println("Dequeued: " + queueA.dequeue());
//        System.out.println("Dequeued: " + queueA.dequeue());
//        System.out.println("Dequeued: " + queueA.dequeue());
//        System.out.println("Dequeued: " + queueA.dequeue());
//
//
//        for(int i =0; i < 100; i++)
//        {
//            queueA.enqueue("cat"+i);
//        }
//        System.out.println("Size is "+queueA.count);
//        for(int j =0; j<=  100; j++)
//        {
//            System.out.println("Dequeued: " + queueA.dequeue());
//        }
//        System.out.println("size is " + queueA.count);
//
//
//    }
}


